from pyrogram import Client, enums
from config import fd_session, f_api
from functions.func import cf_read

api_id = int(cf_read(f_api, 'api', 'api_id'))
api_hash = cf_read(f_api, 'api', 'api_hash')
phone_number = cf_read(f_api, 'api', 'phone_number')

app = Client(
    'ses',
    api_id, api_hash,
    phone_number = phone_number,
    workdir = fd_session,
    parse_mode = enums.ParseMode.HTML
)
