from config import f_config, Me, black_iris, GlobalStack, victims_file, Style
from storage.storage import Settings, JsRead, VictimsEclusionRead
from functions import func
from loader import app

from pyrogram import Client, filters
from pyrogram.types import Message

from datetime import datetime

import asyncio, re, string

# 📃 Списки
@app.on_message(filters.text, group = 6)
async def listi(app: Client, msg: Message):
    
    if msg.from_user and str(msg.from_user.id) in Settings.trusted:
        
        msgt = msg.text
        msgtl = msg.text.lower()
        entity = msg.chat.id
        
        if msg.reply_to_message:
            msgr = msg.reply_to_message
            if not msgr or not msgr.text: return
            msgrt = msgr.text
            msgrtl = msgrt.lower()
        
        
        if msgtl == f'{Settings.prefix}список 1' and msg.reply_to_message:
            
            ids_db = []
            num = 0
            
            for line in msgr.text.html.splitlines():
                tag = re.search(r'(@[\d\w]+|\?user_id=\d+|t\.me/[\w\d]+)', line)
                if tag:
                    num += 1
                    url = tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', '')
                    if num >= 10:
                        text = f'{num}. <code>заразить @{url}</code>'
                    else:
                        text = f'{num}.   <code>заразить @{url}</code>'
                    ids_db.append(text)
            await msgr.reply('💎\n\n' + '\n'.join(ids_db) + '\n\n💎')
            await msg.delete()


        elif msgtl == f'{Settings.prefix}список 2' and msg.reply_to_message:
            
            ids_db = []
            
            for line in msgr.text.html.splitlines():
                tag = re.search(r'(@[\d\w]+|\?user_id=\d+|t\.me/[\w\d]+)', line)
                if tag:
                    url = tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', '')
                    text = f'<code>заразить @{url}</code>'
                    ids_db.append(text)
            await msgr.reply('💎\n\n' + '\n'.join(ids_db) + '\n\n💎')
            await msg.delete()
        
        # CallAPI
        if re.fullmatch(r'{} \+апи'.format(re.escape(Settings.name)), msgtl):
            func.edit_cf(f_config, 'user_settings', 'call_api', 'True')
            Settings.refresh(f_config)
            temp = await msg.reply('🛡 Защита апи успешно включена')
            asyncio.create_task(func.delete_msg([temp, msg], 6))
        
        elif re.fullmatch(r'{} -апи'.format(re.escape(Settings.name)), msgtl):
            func.edit_cf(f_config, 'user_settings', 'call_api', 'False')
            Settings.refresh(f_config)
            temp = await msg.reply('❌ Защита апи выключена')
            asyncio.create_task(func.delete_msg([temp, msg], 6))
        
        elif re.fullmatch(r'{} апи'.format(re.escape(Settings.name)), msgtl):
            if Settings.call_api is True:
                api_status = 'APIStatus - <b>🛡 Защита апи включена</b>'
            else:
                api_status = 'APIStatus - <b>❌ Защита апи выключена</b>'
            temp = await msg.reply(api_status)
            asyncio.create_task(func.delete_msg([temp, msg], 12))
        
        if re.fullmatch(r'({} топ|топ) (жертв||жертв \d+|жертв (((\d+\.\d|\d+)(k|к)|[\d\s]+)|((\d+\.\d|\d+)(k|к)|[\d\s]+)-((\d+\.\d|\d+)(k|к)|[\d\s]+)))'.format(re.escape(Settings.name)), msgtl):
            if msgtl.split(' ')[0] != Settings.name:
                if msg.from_user.id != Me.me.id:
                    return
            await func.top_victims_sort(app, msg, JsRead.js_read, VictimsEclusionRead.js_read, Settings.name)
        
        # биотопы
        if msgtl == f'бт' and msg.from_user.id == Me.me.id:
            await app.send_message(entity, 'Биотоп')
            await msg.delete()
        
        elif msgtl == f'бч' and msg.from_user.id == Me.me.id:
            await app.send_message(entity, 'Биотоп чата')
            await msg.delete()
        
        elif msgtl == 'бз' and msg.from_user.id == Me.me.id:
            await app.send_message(entity, 'Биотоп заражений')
            await msg.delete()
        
        elif msgtl == 'бчз' and msg.from_user.id == Me.me.id:
            await app.send_message(entity, 'Биотоп чата заражений')
            await msg.delete()
        
        elif msgtl == f'кт' and msg.from_user.id == Me.me.id:
            await app.send_message(entity, 'Корп топ')
            await msg.delete()
        
        ###
        # Notexec
        if msg.from_user.id == Me.me.id and re.fullmatch(r'(\.б|/,|\.б (\+|=)|/, (\+|=))', msgtl) and msg.reply_to_message \
        or re.fullmatch(r'({} \.б|{} /,|{} \.б (\+|=)|{} /, (\+|=))'.format(re.escape(Settings.name), re.escape(Settings.name_en), re.escape(Settings.name), re.escape(Settings.name_en)), msgtl) and msg.reply_to_message:
            
            if re.fullmatch(r'({} \.б|{} /,|\.б|/,)'.format(re.escape(Settings.name), re.escape(Settings.name_en)), msgtl):
                auto_zar = False
            else:
                auto_zar = True
                print(GlobalStack.list_zar)
                if GlobalStack.list_zar:
                    temp = await app.send_message(entity, '☕️ Заражения ещё не закончены, ожидайте...')
                    asyncio.create_task(func.delete_msg([temp, msg], 12))
                    return
                while GlobalStack.stop:
                    await asyncio.sleep(3.5)
                GlobalStack.lis_zar = True
            
            design = {
                '1': '✅',
                '2': '➕',
                '3': '🔹',
                '4': '✔️',
                '5': '🔻',
                '6': '➖',
                '7': '💎',
                '8': '⭐️',
                '9': '🔸',
                '10': '❔'
            }
            
            def if_inlist(inflist, exp, num, bio_entity, id, val, cristal=False, exp_bool=True):
                my_exp = (inflist[id]['experience'] if id in inflist else '1')
                my_exp_, exp_ = my_exp, exp
                my_exp = my_exp.replace(' ', '')
                exp = exp.replace(' ', '')
                my_exp, exp = float(my_exp.strip('k').replace(',', '.')), float(exp.strip('k').replace(',', '.'))
                my_exp1 = my_exp
                exp1 = exp
                exp_plus = 'False'
                kd = None
                
                # cooldown of victim
                if JsRead.js_read.get(id) and JsRead.js_read[id].get('infect_time'):
                    infect_time = JsRead.js_read[id]['infect_time']
                    minute = round((datetime.strptime(infect_time, '%d.%m.%Y %H:%M:%S') - datetime.now()).total_seconds() / 60)
                    if minute >= 0:
                        kd = f'🕑 <b>{minute}</b>м'
                
                if Me.me.id == int(id) and val == 3:
                    result = {
                        'text': f'{num}. {bio_entity} | {design["8"]} | <code>@{id}</code>',
                        'exp_plus': 'False'
                    }
                    if cristal: result = {'text': f'{design["7"]}{result["text"]}', 'exp_plus': exp_plus}
                    return result
                
                if Me.me.id == int(id):
                    result = {
                        'text': f'{num}. {bio_entity} | {design["8"]} | {exp_} | <code>@{id}</code>',
                        'exp_plus': 'False'
                    }
                    if cristal: result = {'text': f'{design["7"]}{result["text"]}', 'exp_plus': exp_plus}
                    return result
                
                if val == 5:
                    result = {
                        'text': f'{num}. {bio_entity} | +{my_exp_} | {exp_} | <code>@{id}</code>',
                        'exp_plus': 'False'
                    }
                    if kd:
                        result = {
                            'text': f'{num}. {bio_entity} | {kd}',
                            'exp_plus': 'False'
                        }
                    if cristal: result = {'text': f'{design["7"]}{result["text"]}', 'exp_plus': exp_plus}
                    return result
                
                if val == 8 or val == 4:
                    if not 'k' in my_exp_ and not 'k' in exp_: my_exp = my_exp1; exp = exp1
                    if 'k' in exp_ and 'k' in my_exp_: exp = exp1*1000; my_exp = my_exp1*1000
                    if not 'k' in my_exp_ and 'k' in exp_: exp = exp1*1000; my_exp = my_exp1
                    if 'k' in my_exp_ and not 'k' in exp_: my_exp = my_exp1*1000; exp = exp1
                else:
                    if not 'k' in my_exp_ and not 'k' in exp_: my_exp = my_exp1; exp = exp1/10
                    if 'k' in exp_ and 'k' in my_exp_: exp = exp1*1000; my_exp = my_exp1*10000
                    if not 'k' in my_exp_ and 'k' in exp_: exp = exp1*1000; my_exp = my_exp1*10
                    if 'k' in my_exp_ and not 'k' in exp_: my_exp = my_exp1*10000; exp = exp1*10
                
                if exp > my_exp: #✅➕🔹⭐️💎✔️➖🔻
                    my_exp_ = f'{design["3"]}{my_exp_}'
                    if val not in [4, 3, 8]:
                        exp_plus = 'True'
                    if (val == 4 or val == 8) and num <= 15 and int(my_exp/exp * 100) < 65:
                        exp_plus = 'True'
                else:
                    my_exp_ = f'{design["6"]}{my_exp_}'
                
                if int(Me.me.id) == int(id): my_exp_ = design["8"]
                
                if (val == 4 or val == 8) and num < 15:
                    if 'k' not in str(my_exp) and 'k' not in str(exp):
                        if my_exp <= 150 and int(my_exp/exp * 100) < 90:
                            exp_plus = 'True'
                
                if val == 4 or val == 8:
                    if 'k' not in str(my_exp) and 'k' not in str(exp):
                        if int(my_exp) <= 150 and int(my_exp/exp * 100) < 90:
                            my_exp_ = my_exp_.replace(design['3'], '').replace(design['6'], '')
                            my_exp_ = f'{design["10"]}{my_exp_}'
                            exp_plus = 'True'
                
                if exp_bool is False:
                    if int(Me.me.id) != int(id):
                        my_exp_ = str(my_exp_)[1:]
                    if not 'k' in my_exp_:
                        if int(my_exp_) <= 150 and int(my_exp) < int(exp):
                            my_exp_ = f'{design["10"]}{my_exp_}'
                            exp_plus = 'True'
                        elif val == 3 and int(my_exp_) <= 150:
                            my_exp_ = f'{design["10"]}{my_exp_}'
                            exp_plus = 'True'
                        else:
                            my_exp_ = f'+{my_exp_}'
                    else:
                        my_exp_ = f'+{my_exp_}'
                    result = {
                        'text': {f'{num}. {bio_entity} | {my_exp_} | <code>@{id}</code>'},
                        'exp_plus': exp_plus
                    }
                    if kd:
                        result = {
                            'text': f'{num}. {bio_entity} | {kd}',
                            'exp_plus': 'False'
                        }
                else:
                    result = {
                        'text': f'{num}. {bio_entity} | {my_exp_} | {exp_} | <code>@{id}</code>',
                        'exp_plus': exp_plus
                    }
                    if kd:
                        result = {
                            'text': f'{num}. {bio_entity} | {kd}',
                            'exp_plus': 'False'
                        }
                if cristal: result = {'text': f'{design["7"]}{result["text"]}', 'exp_plus': exp_plus}
                return result
            
            
            def return_in_infect_db(value: str, inflist: dict) -> dict:
                get_key = None
                name = None
                
                for key, val in inflist.items():
                    if 'username' in val:
                        if value == val['username']:
                            get_key = key
                            if 'name' in val:
                                name = name
                            break
                if get_key:
                    if name:
                        return {'id': get_key, 'name': name}
                    return {'id': get_key}
                else:
                    return False
            
            def base_raw_name_sort(raw_name, num, eight=False):
                if eight:
                    raw_name = ''.join(raw_name.rpartition('|')[:-2])[:-1]
                else:
                    raw_name = ''.join(''.join(raw_name.rpartition('|')[:-2]).rpartition('|')[:-2])[:-1]
                
                raw_name = re.split(r'\d+\. ', raw_name)[1]
                raw_name = raw_name.replace('<', '‹').replace('>', '›')
                return func.less_name(raw_name)
            
            ids_db = {}
            ids_db_ = {}
            bioname = ''
            num = 0
            temp_3 = False
            
            bio_mesg = msgrt.split('\n')
            bio_mesg_tags = msgr.text.html.splitlines()
            val = 0
            emoji1 = (Style.prem_nom_magic_wand if msg.from_user.is_premium else Style.magic_wand)
            emoji2 = (Style.prem_nom_king if msg.from_user.is_premium else Style.microscope)
            
            
            if "🔬 Топ Лабораторий чата по Био-опыту:" == bio_mesg[0]:
                bioname = f'{emoji1} ТОП ВКУСНЯШЕК ЧАТА:'
                val = 1
            
            elif '🏢 УЧАСТНИКИ КОРПОРАЦИИ' in bio_mesg[0]:
                corp_name = re.findall('«.+»', bio_mesg[0])[0]
                bioname = f'{emoji1}🔬 УЧАСТНИКИ КОРПОРАЦИИ {corp_name}'
                val = 1
                
            elif "🔬 Топ Лабораторий по био-опыту:" == bio_mesg[0]:
                bioname = f'{emoji2} БИОТОП ПОД СТОЛ:'
                val = 2
            
            elif '🤒 Список ваших болезней:' == bio_mesg[0]:
                bioname = '🤒 ТОП ЗЛЫХ ВКУСНЯШЕК:'
                val = 3
                temp_3 = await app.send_message(entity, "<i><b>My <code>Master</code>, wait a moment, I'm already getting a list... ☕️</i>")
            
            elif '🔬 ТОП БОЛЕЗНЕЙ:' == bio_mesg[0]:
                bioname = f'{emoji2}🤒 ТОП БОЛЕЗНЕЙ:'
                val = 3
            
            elif '🔬 ТОП БОЛЕЗНЕЙ БЕСЕДЫ:' == bio_mesg[0]:
                bioname = f'{emoji1}🤒 ТОП ЗЛЫХ ВКУСНЯШЕК БЕСЕДЫ:'
                val = 3
            
            elif '🦠 Список больных вашим патогеном:' == bio_mesg[0]:
                bioname = '🦠 Топ жертвоприношени:'
                val = 4
            
            elif '🔬 ТОП КОРПОРАЦИЙ ПО ЗАРАЖЕНИЯМ:' == bio_mesg[0]:
                bioname = f'{emoji2} БИОТОП КОРПОРАЦИЙ:'
                val = 5
            
            elif '🦠 Топ моих жертв:' == bio_mesg[0]:
                bioname = '🦠 Топ жертвоприношений:'
                val = 8
            
            elif '🦠 Списoк больных вашим патогеном:' == bio_mesg[0]:
                bioname = '🦠 Списoк больных вашим патогеном:'
                val = 8
            else:
                bioname = '📃 Victimers list'
                val = 0
            
            if not [i for i in [1, 2, 3, 4, 5, 6, 7, 8, 0] if i == val]:
                temp = await msg.reply('Нет такого биотопа в списке')
                await asyncio.sleep(3)
                await msg.delete()
                await temp.delete()
                return
            else:
                if auto_zar:
                    await msg.delete()
            
            inflist = JsRead.js_read
            tags = False
            
            if [i for i in [1, 2, 3, 4, 5, 6, 7, 8] if i == val] or val == 0 and re.fullmatch(r'(\d+\. |).+ \| ([\d ]+[ ,.]+\d+|\d+)[kк]( |.+)\| (заразить @\d+|@\d+)', msgr.text.splitlines()[0].lower()):
                tags = True
                for line in msgr.text.html.splitlines():
                    tag = re.search(r'(@[\d\w]+|\?user_id=[\d\w]+|t\.me/[\w\d]+)', line)
                    if tag:
                        url = tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', '')
                        
                        # get exp
                        if [i for i in [1, 2, 4, 5] if i == val]:
                            exp = ''.join(''.join(line.rpartition('|')[:-2]))[:-1].rpartition('| ')[2].replace(' опыт', '').replace('(', '').replace(')', '').replace('?', '')
                        elif val == 0:
                            exp = ''.join(re.findall(r'(\d+[,.]\d+|\d+)([kк])', line)[-1])
                            exp_int = (float(exp.replace('k', '').replace(',', '.').replace(' ', '')) * 10 if 'k' in exp else int(exp))
                            if exp_int >= 100:
                                exp = str(round(exp_int / 10) / 10).replace(',', '.') + 'k'
                            else:
                                exp = str(round(exp_int * 10))
                            
                        elif val == 8:
                            exp = line.rpartition('| ')[2].split(' ')[0].lower().replace('(', '').replace(')', '').replace('?', '')
                        if val in [3, 6, 7]:
                            exp = '10'
                        if 'к' in exp:
                            exp = exp.replace('к', 'k')
                        exp = exp.replace('@', '')
                        if not 'k' in exp:
                            if int(exp) <= 0:
                                del bio_mesg_tags[num]
                                num -= 1
                                continue
                        
                        num += 1
                        
                        ids_db_[num] = {'url': url, 'exp': exp}
                    else:
                        del bio_mesg_tags[num]
                if val == 0:
                    val = 4
            elif val == 0:
                for link in msgr.text.html.splitlines():
                    tag = re.search(r'(@[\d\w]+|\?user_id=\d+|t\.me/[\w\d]+)', link)
                    if tag:
                        url = tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', '')
                        num += 1
                        
                        ids_db_[num] = {'url': url, 'exp': '10'}
                        val = 3
            
            
            for n, (key_, val_) in enumerate(ids_db_.items(), 1):
                url = val_['url']
                ids = url
                num = int(key_) - 1
                exp = val_['exp']
                exp_plus = 'False'
                except_no_way = False
                get_ses_user = False
                link_in_zar = False
                id = None
                username = None
                name = None
                new = False
                callapi = True
                callbot = False
                
                if url != 'https://t.me/c//99999999':
                    if Settings.call_api and [i for i in [1, 2] if i != val]:
                        callapi = False
                    if not ids.isdigit():
                        callbot = True
                        await asyncio.sleep(2.5)
                    search = await func.check_in_db(app, ids, JsRead, victims_file, bot_getid = callbot, get_entity = callapi, iris_id = black_iris)
                    zar = search['instance']
                    if search['not_found'] == 'True':
                        id = ids
                        except_no_way = True
                    if search['zar'] == 'True':
                        link_in_zar = True
                    if zar:
                        id = str(list(zar)[0])
                        if 'name' in zar[id]:
                            name = zar[id]['name']
                    else:
                        except_no_way = True

                    # set name
                    if name is None or name.isdigit():
                        if tags:
                            if val in [1, 2, 4, 5]:
                                name = re.search(r'">.+</a>', bio_mesg_tags[num])[0][:-4][2:]
                            elif val == 3:
                                name = re.search(r'">.+</a>', bio_mesg_tags[num])[0][:-4][2:]
                                name = f'«{name}»'
                            elif val == 8:
                                name =  re.search(r'">.+</a>', bio_mesg_tags[num])[0][:-4][2:]
                        else:
                            name = 'неизв.'
                            if id:
                                name_ = await func.name_searcher_by_id(app, id)
                                if name_:
                                    name = name_
                # set name if url is unknown
                else:
                    re.search(r'">.+</a>', bio_mesg_tags[num])[0][:-4][2:]
                
                name = name.replace('<', '‹').replace('>', '›')
                name = func.less_name(name)
                bio_entity = f'<a href=tg://openmessages?user_id={id}>{name}</a>'
                if url.isdigit():
                    if except_no_way is False:
                        if link_in_zar:
                            if val == 3:
                                gamer = if_inlist(inflist, exp, n, bio_entity, id, val, exp_bool=False)
                                exp_plus = gamer['exp_plus']
                                gamer = gamer['text']
                            else:
                                gamer = if_inlist(inflist, exp, n, bio_entity, id, val)
                                exp_plus = gamer['exp_plus']
                                gamer = gamer['text']
                        else:
                            exp_plus = 'True'
                            new = True
                            if val == 3:
                                gamer = f'{n}. {bio_entity} | {design["9"]} | <code>@{id}</code>'
                            else:
                                gamer = f'{n}. {bio_entity} | {design["9"]} | {exp} | <code>@{id}</code>'
                    else:
                        if link_in_zar:
                            if val == 3:
                                gamer = if_inlist(inflist, exp, n, bio_entity, id, val, exp_bool=False)
                                exp_plus = gamer['exp_plus']
                                gamer = gamer['text']
                            else:
                                gamer = if_inlist(inflist, exp, n, bio_entity, id, val)
                                exp_plus = gamer['exp_plus']
                                gamer = gamer['text']
                        else:
                            exp_plus = 'True'
                            new = True
                            if val == 3:
                                gamer = f'{n}. {bio_entity} | {design["9"]} | <code>@{id}</code>'
                            else:
                                gamer = f'{n}. {bio_entity} | {design["9"]} | {exp} | <code>@{id}</code>'
                
                else:
                    if except_no_way is False:
                        if link_in_zar:
                            gamer = if_inlist(inflist, exp, n, bio_entity, id, val)
                            exp_plus = gamer['exp_plus']
                            gamer = gamer['text']
                        else:
                            exp_plus = 'True'
                            new = True
                            gamer = f'{n}. {bio_entity} | {design["9"]} | {exp} | <code>@{id}</code>'
                    else:
                        exp_plus = 'True'
                        new = True
                        if val == 5:
                            gamer = f'{n}. {bio_entity} | {exp} | <code>@{id}</code>'
                        else:
                            gamer = f'{design["7"]}{n}. {bio_entity} | {design["9"]} | <code>@{id}</code>'
                
                gamer = ''.join(gamer)
                
                ids_db[num] = gamer
                
                if auto_zar and exp_plus == 'True' and '=' not in msgtl or auto_zar and '=' in msgtl and new:
                    
                    if id in VictimsEclusionRead.js_read or func.check_infect_time(id, JsRead.js_read):
                        continue
                    while GlobalStack.stop:
                        await asyncio.sleep(3.5)
                    await asyncio.sleep(3)
                    await app.send_message(entity, f'Заразить @{id}')
            
            if auto_zar is False:
                
                if temp_3:
                    await temp_3.delete()
                
                result = bioname+'\n'+'\n'.join(ids_db.values())
                await msg.delete()
                if len(result) > 8192:
                    result_ = '\n'.join(result.split('\n')[:51])
                    result1 = '\n'.join(result.split('\n')[51:])
                    temp = await msgr.reply(result_)
                    temp1 = await temp.reply(result1)
                    await msg.delete()
                    asyncio.create_task(func.delete_msg([temp1, temp], 90))
                else:
                    temp = await msgr.reply(result)
                    await msg.delete()
                    asyncio.create_task(func.delete_msg(temp, 90))
            else:
                await func.bot_clear_msg(app, black_iris)
                GlobalStack.list_zar = False
        
        
        # Notexec without my exp
        if msg.from_user.id == Me.me.id and re.fullmatch(r'(\.е|/t|\.е \+|/t \+)', msgtl) and msg.reply_to_message \
        or re.fullmatch(r'({} \.е|{} /t|{} \.е \+|{} /t \+)'.format(re.escape(Settings.name), re.escape(Settings.name_en), re.escape(Settings.name), re.escape(Settings.name_en)), msgtl) and msg.reply_to_message:
            
            design = {
                '1': '✅',
                '2': '➕',
                '3': '🔹',
                '4': '✔️',
                '5': '🔻',
                '6': '➖',
                '7': '💎',
                '8': '⭐️',
                '9': '🔸',
                '10': '❔'
            }
            
            def if_inlist(inflist, exp, num, bio_entity, id, val, cristal=False, exp_bool=True):
                my_exp = (inflist[id]['experience'] if id in inflist else '1')
                my_exp_, exp_ = my_exp, exp
                my_exp = my_exp.replace(' ', '')
                exp = exp.replace(' ', '')
                my_exp, exp = float(my_exp.strip('k').replace(',', '.')), float(exp.strip('k').replace(',', '.'))
                my_exp1 = my_exp
                exp1 = exp
                exp_plus = 'False'
                
                if Me.me.id == int(id) and val == 3:
                    result = {
                        'text': f'{num}. {bio_entity} | {design["8"]} | <code>@{id}</code>',
                        'exp_plus': 'False'
                    }
                    if cristal: result = {'text': f'{design["7"]}{result["text"]}', 'exp_plus': exp_plus}
                    return result
                if Me.me.id == int(id):
                    result = {
                        'text': f'{num}. {bio_entity} | {design["8"]} | {exp_} | <code>@{id}</code>',
                        'exp_plus': 'False'
                    }
                    if cristal: result = {'text': f'{design["7"]}{result["text"]}', 'exp_plus': exp_plus}
                    return result
                
                if val == 5:
                    result = {
                        'text': f'{num}. {bio_entity} | +{my_exp_} | {exp_} | <code>@{id}</code>',
                        'exp_plus': 'False'
                    }
                    if cristal: result = {'text': f'{design["7"]}{result["text"]}', 'exp_plus': exp_plus}
                    return result
                
                if val == 8 or val == 4:
                    if not 'k' in my_exp_ and not 'k' in exp_: my_exp = my_exp1; exp = exp1
                    if 'k' in exp_ and 'k' in my_exp_: exp = exp1*1000; my_exp = my_exp1*1000
                    if not 'k' in my_exp_ and 'k' in exp_: exp = exp1*1000; my_exp = my_exp1
                    if 'k' in my_exp_ and not 'k' in exp_: my_exp = my_exp1*1000; exp = exp1
                else:
                    if not 'k' in my_exp_ and not 'k' in exp_: my_exp = my_exp1; exp = exp1/10
                    if 'k' in exp_ and 'k' in my_exp_: exp = exp1*1000; my_exp = my_exp1*10000
                    if not 'k' in my_exp_ and 'k' in exp_: exp = exp1*1000; my_exp = my_exp1*10
                    if 'k' in my_exp_ and not 'k' in exp_: my_exp = my_exp1*10000; exp = exp1*10
                
                if exp > my_exp: #✅➕🔹⭐️💎✔️➖🔻
                    my_exp_ = f'{design["3"]}{my_exp_}'
                    if val not in [4, 3, 8]:
                        exp_plus = 'True'
                    if (val == 4 or val == 8) and num <= 15 and int(my_exp/exp * 100) < 65:
                        exp_plus = 'True'
                else:
                    my_exp_ = f'{design["6"]}{my_exp_}'
                
                if int(Me.me.id) == int(id): my_exp_ = design["8"]
                
                if (val == 4 or val == 8) and num < 15:
                    if 'k' not in str(my_exp) and 'k' not in str(exp):
                        if my_exp <= 150 and int(my_exp/exp * 100) < 90:
                            exp_plus = 'True'
                
                if val == 4 or val == 8:
                    if 'k' not in str(my_exp) and 'k' not in str(exp):
                        if int(my_exp) <= 150 and int(my_exp/exp * 100) < 90:
                            my_exp_ = my_exp_.replace(design['3'], '').replace(design['6'], '')
                            my_exp_ = f'{design["10"]}{my_exp_}'
                            exp_plus = 'True'
                
                if exp_bool is False:
                    if int(Me.me.id) != int(id):
                        my_exp_ = str(my_exp_)[1:]
                    if not 'k' in my_exp_:
                        if int(my_exp_) <= 150 and int(my_exp) < int(exp):
                            my_exp_ = f'{design["10"]}{my_exp_}'
                            exp_plus = 'True'
                        elif val == 3 and int(my_exp_) <= 150:
                            my_exp_ = f'{design["10"]}{my_exp_}'
                            exp_plus = 'True'
                        else:
                            my_exp_ = f'+{my_exp_}'
                    else:
                        my_exp_ = f'+{my_exp_}'
                    result = {
                        'text': {f'{num}. {bio_entity} | {my_exp_} | <code>@{id}</code>'},
                        'exp_plus': exp_plus
                    }
                else:
                    result = {
                        'text': f'{num}. {bio_entity} | {my_exp_} | {exp_} | <code>@{id}</code>',
                        'exp_plus': exp_plus
                    }
                if cristal: result = {'text': f'{design["7"]}{result["text"]}', 'exp_plus': exp_plus}
                return result
            
            
            def return_in_infect_db(value: str, inflist: dict) -> dict:
                get_key = None
                name = None
                
                for key, val in inflist.items():
                    if 'username' in val:
                        if value == val['username']:
                            get_key = key
                            if 'name' in val:
                                name = name
                            break
                if get_key:
                    if name:
                        return {'id': get_key, 'name': name}
                    return {'id': get_key}
                else:
                    return False
            
            def base_raw_name_sort(raw_name, num, eight=False):
                if eight:
                    raw_name = ''.join(raw_name.rpartition('|')[:-2])[:-1]
                else:
                    raw_name = ''.join(''.join(raw_name.rpartition('|')[:-2]).rpartition('|')[:-2])[:-1]
                
                raw_name = re.split(r'\d+\. ', raw_name)[1]
                raw_name = raw_name.replace('<', '‹').replace('>', '›')
                return func.less_name(raw_name)
            
            ids_db = {}
            ids_db_ = {}
            bioname = ''
            num = 0
            temp_3 = False
            
            bio_mesg = msgrt.split('\n')
            bio_mesg_tags = msgr.text.html.splitlines()
            val = 0
            emoji1 = (Style.prem_nom_magic_wand if msg.from_user.is_premium else Style.magic_wand)
            emoji2 = (Style.prem_nom_king if msg.from_user.is_premium else Style.microscope)
            
            
            if "🔬 Топ Лабораторий чата по Био-опыту:" == bio_mesg[0]:
                bioname = f'{emoji1} ТОП ВКУСНЯШЕК ЧАТА:'
                val = 1
            
            elif '🏢 УЧАСТНИКИ КОРПОРАЦИИ' in bio_mesg[0]:
                corp_name = re.findall('«.+»', bio_mesg[0])[0]
                bioname = f'{emoji1}🔬 УЧАСТНИКИ КОРПОРАЦИИ {corp_name}'
                val = 1
                
            elif "🔬 Топ Лабораторий по био-опыту:" == bio_mesg[0]:
                bioname = f'{emoji2} БИОТОП ПОД СТОЛ:'
                val = 2
            
            elif '🤒 Список ваших болезней:' == bio_mesg[0]:
                bioname = '🤒 ТОП ЗЛЫХ ВКУСНЯШЕК:'
                val = 3
                temp_3 = await app.send_message(entity, "<i><b>My <code>Master</code>, wait a moment, I'm already getting a list... ☕️</i>")
            
            elif '🔬 ТОП БОЛЕЗНЕЙ:' == bio_mesg[0]:
                bioname = f'{emoji2}🤒 ТОП БОЛЕЗНЕЙ:'
                val = 3
            
            elif '🔬 ТОП БОЛЕЗНЕЙ БЕСЕДЫ:' == bio_mesg[0]:
                bioname = f'{emoji1}🤒 ТОП ЗЛЫХ ВКУСНЯШЕК БЕСЕДЫ:'
                val = 3
            
            elif '🦠 Список больных вашим патогеном:' == bio_mesg[0]:
                bioname = '🦠 Топ жертвоприношени:'
                val = 4
            
            elif '🔬 ТОП КОРПОРАЦИЙ ПО ЗАРАЖЕНИЯМ:' == bio_mesg[0]:
                bioname = f'{emoji2} БИОТОП КОРПОРАЦИЙ:'
                val = 5
            
            elif '🦠 Топ моих жертв:' == bio_mesg[0]:
                bioname = '🦠 Топ жертвоприношений:'
                val = 8
            
            elif '🦠 Списoк больных вашим патогеном:' == bio_mesg[0]:
                bioname = '🦠 Списoк больных вашим патогеном:'
                val = 8
            else:
                bioname = '📃 Victimers list'
                val = 0
            
            if not [i for i in [1, 2, 3, 4, 5, 6, 7, 8, 0] if i == val]:
                temp = await msg.reply('Нет такого биотопа в списке')
                await asyncio.sleep(3)
                await msg.delete()
                await temp.delete()
                return
            
            inflist = JsRead.js_read
            tags = False
            
            if [i for i in [1, 2, 3, 4, 5, 6, 7, 8] if i == val] or val == 0 and re.fullmatch(r'(\d+\. |).+ \| ([\d ]+[ ,.]+\d+|\d+)[kк]( |.+)\| (заразить @\d+|@\d+)', msgr.text.splitlines()[0].lower()):
                tags = True
                for line in msgr.text.html.splitlines():
                    tag = re.search(r'(@[\d\w]+|\?user_id=[\d\w]+|t\.me/[\w\d]+)', line)
                    if tag:
                        url = tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', '')
                        
                        # get exp
                        if [i for i in [1, 2, 4, 5] if i == val]:
                            exp = ''.join(''.join(line.rpartition('|')[:-2]))[:-1].rpartition('| ')[2].replace(' опыт', '').replace('(', '').replace(')', '').replace('?', '')
                        elif val == 0:
                            exp = ''.join(re.findall(r'(\d+[,.]\d+|\d+)([kк])', line)[-1])
                            exp_int = (float(exp.replace('k', '').replace(',', '.').replace(' ', '')) * 10 if 'k' in exp else int(exp))
                            if exp_int >= 100:
                                exp = str(round(exp_int / 10) / 10).replace(',', '.') + 'k'
                            else:
                                exp = str(round(exp_int * 10))
                            
                        elif val == 8:
                            exp = line.rpartition('| ')[2].split(' ')[0].lower().replace('(', '').replace(')', '').replace('?', '')
                        if val in [3, 6, 7]:
                            exp = '10'
                        if 'к' in exp:
                            exp = exp.replace('к', 'k')
                        exp = exp.replace('@', '')
                        if not 'k' in exp:
                            if int(exp) <= 0:
                                del bio_mesg_tags[num]
                                num -= 1
                                continue
                        
                        num += 1
                        
                        ids_db_[num] = {'url': url, 'exp': exp}
                    else:
                        del bio_mesg_tags[num]
                if val == 0:
                    val = 4
            elif val == 0:
                for link in msgr.text.html.splitlines():
                    tag = re.search(r'(@[\d\w]+|\?user_id=\d+|t\.me/[\w\d]+)', link)
                    if tag:
                        url = tag[0].replace('?user_id=', '').replace('@', '').replace('t.me/', '')
                        num += 1
                        
                        ids_db_[num] = {'url': url, 'exp': '10'}
                        val = 3
            
            
            for n, (key_, val_) in enumerate(ids_db_.items(), 1):
                url = val_['url']
                ids = url
                num = int(key_) - 1
                exp = val_['exp']
                exp_plus = 'False'
                except_no_way = False
                get_ses_user = False
                link_in_zar = False
                id = None
                username = None
                name = None
                new = False
                callapi = True
                callbot = False
                
                if url != 'https://t.me/c//99999999':
                    if Settings.call_api and [i for i in [1, 2] if i != val]:
                        callapi = False
                    if not ids.isdigit():
                        callbot = True
                        await asyncio.sleep(2.5)
                    search = await func.check_in_db(app, ids, JsRead, victims_file, bot_getid = callbot, get_entity = callapi, iris_id = black_iris)
                    zar = search['instance']
                    if search['not_found'] == 'True':
                        id = ids
                        except_no_way = True
                    if search['zar'] == 'True':
                        link_in_zar = True
                    if zar:
                        id = str(list(zar)[0])
                        if 'name' in zar[id]:
                            name = zar[id]['name']
                    else:
                        except_no_way = True

                    # set name
                    if name is None or name.isdigit():
                        if tags:
                            if val in [1, 2, 4, 5]:
                                name = re.search(r'">.+</a>', bio_mesg_tags[num])[0][:-4][2:]
                            elif val == 3:
                                name = re.search(r'">.+</a>', bio_mesg_tags[num])[0][:-4][2:]
                                name = f'«{name}»'
                            elif val == 8:
                                name =  re.search(r'">.+</a>', bio_mesg_tags[num])[0][:-4][2:]
                        else:
                            name = 'неизв.'
                            if id:
                                name_ = await func.name_searcher_by_id(app, id)
                                if name_:
                                    name = name_
                # set name if url is unknown
                else:
                    re.search(r'">.+</a>', bio_mesg_tags[num])[0][:-4][2:]
                
                name = name.replace('<', '‹').replace('>', '›')
                name = func.less_name(name)
                bio_entity = f'<a href=tg://openmessages?user_id={id}>{name}</a>'
                if url.isdigit():
                    if except_no_way is False:
                        if val == 3:
                            gamer = f'{n}. {bio_entity} | <code>@{id}</code>'
                        else:
                            gamer = f'{n}. {bio_entity} | {exp} | <code>@{id}</code>'
                    else:
                        if val == 3:
                            gamer = f'{n}. {bio_entity} | <code>@{id}</code>'
                        else:
                            gamer = f'{n}. {bio_entity} | {exp} | <code>@{id}</code>'
                
                else:
                    if except_no_way is False:
                        gamer = f'{n}. {bio_entity} | {exp} | <code>@{id}</code>'
                    else:
                        if val == 5:
                            gamer = f'{n}. {bio_entity} | {exp} | <code>@{id}</code>'
                        else:
                            gamer = f'{design["7"]}{n}. {bio_entity} | <code>@{id}</code>'
                
                gamer = ''.join(gamer)
                
                ids_db[num] = gamer
            
            if temp_3:
                await temp_3.delete()
            
            result = bioname+'\n'+'\n'.join(ids_db.values())
            await msg.delete()
            if len(result) > 8192:
                result_ = '\n'.join(result.split('\n')[:51])
                result1 = '\n'.join(result.split('\n')[51:])
                temp = await msgr.reply(result_)
                temp1 = await temp.reply(result1)
                await msg.delete()
                asyncio.create_task(func.delete_msg([temp1, temp], 90))
            else:
                temp = await msgr.reply(result)
                await msg.delete()
                asyncio.create_task(func.delete_msg(temp, 90))
#